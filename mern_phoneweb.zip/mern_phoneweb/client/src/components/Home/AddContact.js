
import Header from "../Common_component/Header";
import Footer from "../Common_component/Footer";
import  { AddContactinputfield  } from '../Login_register/Inputfield'; 
import { useState } from 'react';
import { useNavigate  } from 'react-router-dom';
import  { addContactUser } from '../../services/api';


function AddContact() {
  const initial={
    name:'',
    number:''
    }
 
const[user,setUser]=useState(initial);
const navigate= useNavigate();

const onValueChange = (e) =>{
    setUser({...user,[e.target.name]:e.target.value})
  };

const handleSubmit = async (e) =>
     {
       e.preventDefault();
       let result = await addContactUser(user);
      //  console.log(result);
       if(  result && result.data && result.data.message ) 
       {
        //loalhost in data store
        alert(result.data.message);
        localStorage.setItem("Username", user.name);
        navigate('/home');
       }
       else{
        console.log("result",result);
        alert(result.data.error);
       }
       
    }     

  return (
    <>
        <Header/>
        <div className="container mt-5">
    
     <h4 className='mt-2'>Add Contact</h4>
    <form className="mt-2"  onSubmit={handleSubmit}>             
               { AddContactinputfield.map((inputfields, index) => {
                    return (
                            <div key={index} > 
                                <div className="row mt-3">
                                    <div className="col-lg-12"><label name= {inputfields.fieldname}>  {inputfields.fieldname} </label></div>
                                </div>
                                <div className="row">
                                  <div className="col-lg-12"> 
                                    <input type={inputfields.type} 
                                        name= {inputfields.fieldvalue} 
                                        placeholder=  {inputfields.fieldname}
                                        onChange={(e)=>onValueChange(e)} 
                                        /> 
                                </div>
                                </div>
                            </div>
                    );
                })}  
           
                
        <div className="row mt-4">
            <div className="col-lg-4"></div>
            <div className="col-lg-4"> <input type="submit" /></div>
            <div className="col-lg-4"></div>
        </div>
    </form>
   
    </div>
    <br/>
    <br/>
        <Footer/>
    </>
  )
}

export default AddContact