import Userdata from "../schema/userSchema.js";
import Contactdatas from "../schema/contactSchema.js";

//register api
export const addUser = async (req, res) => {
  const { name, email, password } = req.body;
  //check filed is empty or not

  if (!name || !email || !password) {
    return res.status(200).json({ error: "plz filled the fields properly" });
  }
  //find email not present already
  try {
    const userExist = await Userdata.findOne({ email: email });

    if (userExist) {
      return res.status(200).json({ error: "email already exist" });
    } else {
      const newUser = new Userdata({ name, email, password });
      await newUser.save();
      res.status(201).json({ message: "Register Successfully", newUser });
    }

  } catch (error) {
    console.log(error);
  }
};
//login user
export const findUser = async (req, res) => {

  const { name, password } = req.body;
  //check filed is empty or not

  if (!name || !password) {

    return res.status(200).json({ error: "plz filled the fields properly" });

  }
  //find email not present already
  try {
    const userExist = await Userdata.findOne({ name: name, password: password });
    if (userExist) {
      const token = await userExist.generateAuthToken();
      res.cookie("jwtoken", token);
      return res
        .status(201)
        .json({ message: "user signin successfully", token });

    } else {

      return res.status(200).json({ error: "invalied crenditial" });
    }

  } catch (error) {
    console.log(error);
  }
};
//addcontactuser

export const addcontactuser = async (req, res) => {
  const { name, number } = req.body;
  //check filed is empty or not

  if (!name || !number) {
    return res.status(200).json({ error: "plz filled the fields properly" });
  }
  //find email not present already
  try {
    const userExist = await Contactdatas.findOne({ name: name });

    if (userExist) {
      return res.status(200).json({ error: "Contact already exist" });
    } else {
      const newUser = new Contactdatas({ name: name, conatctNumber: number });
      await newUser.save();
      res.status(201).json({ message: "Contact added  Successfully", newUser });
    }

  } catch (error) {
    console.log(error);
  }
};

// export const viewContact = async (req, res) => {

//   try {
//     const users = await Contactdatas.find();
//     res.status(201).json({data:users});
//   } catch (error) {
//     res.status(401).json({ message: error.message });
//   } 
// };
export const viewContact = async (req, res) => {

  try {
    const allUser = await Contactdatas.find({});
    const page = parseInt(req.query.page)
    const limit = parseInt(req.query.limit)

    const startIndex = (page - 1) * limit
    const lastIndex = (page) * limit

    const users = {}
    users.totalUser = allUser.length;
    users.pagecount = Math.ceil(allUser.length / limit);

    if (lastIndex < allUser.length) {
      users.next = {
        page: page + 1,
      }
    }
    if (startIndex > 0) {
      users.prev = {
        page: page - 1,
      }
    }
    users.result = allUser.slice(startIndex, lastIndex);
    // res.json(users)
    res.status(201).json({ data: users });
  } catch (error) {
    res.status(401).json({ message: error.message });
  }
};


export const deleteContact = async (req, res) => {
  const { id } = req.body;
  try {
    const users = await Contactdatas.deleteOne({ id })
    console.log("users", users);
    if (users.acknowledged) {
      res.status(201).json({ message: "deleted successfully" });
    }
    else {
      res.status(200).json({ error: "something wrong" });
    }

  } catch (error) {
    res.status(401).json({ message: error.message });
  }
};

export const SearchContactUser = async (req, res) => {
  const { name } = req.body;
  try {

    const users = await Contactdatas.find({ name })

    if (users.length) {
      res.status(201).json({ message: "find successfully", data: users });
    }
    else {
      res.status(200).json({ error: "No user find " });
    }

  } catch (error) {
    res.status(401).json({ message: error.message });
  }
};

export const getContactDetails = async (req, res) => {
  const { id } = req.body;
  console.log("id", id);
  try {

    const users = await Contactdatas.find({ _id: id })
    console.log("users", users);
    if (users.length) {
      res.status(201).json({ message: "find successfully", data: users });
    }
    else {
      res.status(200).json({ error: "No user find " });
    }

  } catch (error) {
    res.status(401).json({ message: error.message });
  }
};

//update api for contact
export const updateContactdata = async (req, res) => {
  const { uname, unumber, cid } = req.body;
  let uids = cid.id;

  try {

    if (uids) {
      let result = await Contactdatas.findOneAndUpdate({ _id: uids },
        {
          "name": uname,
          "conatctNumber": unumber

        });
      console.log("result", result);
      res.status(201).json({ message: "update successfully", data: result });
    }
    else {
      res.status(200).json({ error: "No user find " });
    }

  } catch (error) {
    res.status(401).json({ message: error.message });
  }
};


/* 
work done in 
login 
validation set
jwtoken 
cookies

register
validation 

*/
