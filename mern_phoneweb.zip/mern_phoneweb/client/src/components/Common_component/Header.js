import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';

export const menuItems = [
    {
      title: 'Home',
      url: '/home',
    },
    {
        title: 'Add Contact',
        url: '/addcontact',
      },
    {
      title: 'Delete Contact',
      url: '/deletecontact',
    },
    {
      title: 'Update Contact',
      url: '/updatecontact',
    },
   
      {
        title: 'Search Contact',
        url: '/searchcontact',
      }, 
       {
        title: 'View Contact',
        url: '/viewcontact',
      },
  ];

function CollapsibleExample() {
  return (
    <Navbar collapseOnSelect expand="lg" className="bg-danger-subtle">
      <Container>
        <Navbar.Brand href="#home">Home Design</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
        <Nav>
                
            { menuItems.map((menu, index) => {
                    return (
                            <Nav.Link key={index} href = {menu.url} > {menu.title} </Nav.Link>
                    );
          })}  
           
        </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default CollapsibleExample;