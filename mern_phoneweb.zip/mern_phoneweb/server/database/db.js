import mongoose from "mongoose";

const Connection = async () =>{
    const URL = `mongodb+srv://project1:project1@cluster0.vrzxbhs.mongodb.net/project1`
    try{
        const DB_OPTION = {
            dbName:"user" 
        };
        await mongoose.connect(URL,DB_OPTION );
        console.log("connected successful");
    }
    catch(error)
    {
        console.log(error);

    }
};
export default Connection;