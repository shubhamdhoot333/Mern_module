import React,{useEffect,useState} from 'react'
import Header from "../Common_component/Header"
import Footer from "../Common_component/Footer";
import { useParams,useNavigate } from "react-router-dom";

import { getContactDetails,updateContactdata }from  '../../services/api';

function UpdateContactView() {
    const navigate= useNavigate();
    const initial={
        cid:'',
        uname:'',
        unumber:'',
    }
    const [name,setName]=useState("");
    const [cnumber,setCnumber]=useState("");
    const [user,setUser]=useState(initial);
    let  id  = useParams();
    useEffect(() => {
        loadContactDetails();
    }, []);

    const loadContactDetails= async()=>{
        const response = await getContactDetails(id);
        console.log(response.data.data[0].name);
        if(response.data.data.length>0)
        {
            setName(response.data.data[0].name);
            setCnumber(response.data.data[0].conatctNumber);
        }
     } 
    const edithandleSubmit = async (e) => {
       e.preventDefault();
       user.cid=id;
       user.uname=name;
       user.unumber=cnumber;
       console.log("user",user);
       
       const resultdata = await updateContactdata(user);
       alert("result",resultdata);
       navigate('/home');
       

      };
  
  return (

    <div>
        <Header/>
        <form onSubmit={edithandleSubmit}>
             <div className="row ">
                  <div>
                    <label className="form-label">Name</label>
                  </div>
                  <div>
                    <input
                      type="text"
                      name="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                 
                </div>
                <div className="row ">
                  <div>
                    <label className="form-label">phone Number</label>
                  </div>
                  <div>
                    <input
                      type="text"
                      name="phone"
                      value={cnumber}
                      onChange={(e) => setCnumber(e.target.value)}
                    />
                  </div>
                 
                </div>

               
               
                <div className="row mt-3">
                  <div className="col-lg-5"></div>
                  <div className="col-lg-2">
                    <input
                      type="submit"
                      value="submit"
                      className="btn btn-primary"
                    />
                  
                  </div>
                  <div className="col-lg-5"></div>
                </div>
             
            </form>
        <Footer/>
       </div>
  )
}

export default UpdateContactView