import { PersonCircle } from 'react-bootstrap-icons';
import { useState } from 'react';
import { Link,useNavigate } from 'react-router-dom';
import  { addUser } from '../../services/api';
import { Registerinputfields } from './Inputfield';
function Register() {
    const initial={
        name:'',
        email:'',
        password:''
        }

    const[user,setUser]=useState(initial);
    const navigate= useNavigate();
    
    const onValueChange = (e) =>{
        setUser({...user,[e.target.name]:e.target.value})
      };
    
    const handleSubmit = async (e) =>
         {
            e.preventDefault();
            console.log("user add", user);
            let result = await addUser(user);
            console.log(result);
           if(result.data.message)
            {
             //loalhost in data store
             alert(result.data.message);
             navigate('/');
            }
            else{
             console.log("result",result);
             alert(result.data.error);
            }
         } 
      
   
  return (
    <>     
    <div className="container">
    
    <PersonCircle size={100} className="mt-4"/>
    <h4 className='mt-2'>Register Form</h4>
    <form className="mt-4" onSubmit={handleSubmit}>             
               { Registerinputfields.map((inputfields, index) => {
                    return (
                            <div key={index} > 
                                <div className="row mt-3">
                                    <div className="col-lg-12"><label name={inputfields.fieldname}>  {inputfields.fieldname} </label></div>
                                </div>
                                <div className="row">
                                  <div className="col-lg-12"> 
                                    <input type="text" 
                                        name= {inputfields.fieldvalue} 
                                        placeholder=  {inputfields.fieldname}
                                        onChange={(e)=>onValueChange(e)} /> 
                                </div>
                                </div>
                            </div>
                    );
                })}  
           
                
        <div className="row mt-4">
            <div className="col-lg-4"></div>
            <div className="col-lg-4"> <input type="submit" /></div>
            <div className="col-lg-4"></div>
        </div>
        <div className='row mt-2'>
            <div className="col-lg-4"></div>
            <div className="col-lg-4"> <Link to ="/">Click here to Login </Link></div>
            <div className="col-lg-4"></div>
    </div>
    </form>
    </div>
 
    </>
  )
}

export default Register
