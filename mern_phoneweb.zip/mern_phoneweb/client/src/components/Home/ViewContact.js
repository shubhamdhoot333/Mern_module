import React, { useEffect, useState } from 'react';
import Header from "../Common_component/Header";
import Footer from "../Common_component/Footer";
import { viewContact } from '../../services/api';
import ReactPaginate from 'react-paginate';
import { useRef } from "react";

function ViewContact() {
  const [contact, setContact] = useState("");
  const [limit, setLimit] = useState(4);
  const [pageCount, setPageCount] = useState(1);

  const currentPage = useRef();

  useEffect(() => {
    currentPage.current = 1;
    getAllOrder(currentPage, limit);
  }, [])

  const getAllOrder = async (currentPage, limit) => {
    const order_data = await viewContact(currentPage, limit);
    setContact(order_data.data.data.result);
    setPageCount(order_data.data.data.pagecount);
    console.log(order_data.data.data.result, order_data.data.data.pagecount);

  };
  //pagination
  function handlePageClick(e) {
    console.log(e);
    currentPage.current = e.selected + 1;
    getAllOrder(currentPage, limit);


  }

  return (
    <div>
      <Header />
      <h4>view Contact </h4>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">id</th>
            <th scope="col">Name </th>
            <th scope="col">Number</th>

          </tr>
        </thead>
        <tbody>

          {
            contact ?
              (contact.map((value, index) => {
                return (
                  <tr key={index}>
                    <td>*</td>
                    <td> {value.name}</td>
                    <td> {value.conatctNumber}</td>
                  </tr>


                )
              }))
              :
              "no data found"}
        </tbody>
      </table>
      <ReactPaginate
        breakLabel="..."
        nextLabel="next >"
        onPageChange={handlePageClick}
        pageRangeDisplayed={5}
        pageCount={pageCount}
        previousLabel="< previous"
        renderOnZeroPageCount={null}
        marginPagesDisplayed={2}
        containerClassName="pagination justify-content-center"
        pageClassName="page-item"
        pageLinkClassName="page-link"
        previousClassName="page-item"
        previousLinkClassName="page-link"
        nextClassName="page-item"
        nextLinkClassName="page-link"
        activeClassName="active"
        forcePage={currentPage.current - 1}
      />
      <Footer />
    </div>
  )
}

export default ViewContact



