import mongoose from "mongoose";
import  jwt  from "jsonwebtoken";
const usersSchema = new mongoose.Schema({

    name:String,
    email:String,
    password:String

});

usersSchema.methods.generateAuthToken = async function(){
    try{
        let token = jwt.sign({_id:this._id}, "MYNAMEISSHUBHAMDHOOTFROMJODHPUR",{expiresIn: '1d'} );
        return token;
       
    }
    catch(error){console.log(error);}
}
const userdatas = mongoose.model("user", usersSchema);

export default userdatas;