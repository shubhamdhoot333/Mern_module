/* eslint-disable react-hooks/exhaustive-deps */
import React,{ useEffect, useState } from 'react';
import Header from "../Common_component/Header";
import Footer from "../Common_component/Footer";
import { viewContact,deleteContact }from  '../../services/api';
import { useNavigate  } from 'react-router-dom';


function DeleteContact() {
  const [contact,setContact]=useState("");
  const navigate= useNavigate();
  
  useEffect(()=>{
    getAllOrder();
  },[])

  const getAllOrder = async () => {
    const order_data = await viewContact();
    setContact(order_data.data.data);
    console.log(order_data.data.data);

  };
  const delId = async(id)=>{
          console.log(id);
          const result = await deleteContact(id);
          // console.log(result.data.message,"result");
          if(  result && result.data && result.data.message ) 
          {
           //loalhost in data store
           alert(result.data.message);
            navigate('/home');
          }
          else{
           console.log("result",result);
           alert(result.data.error);
          }
          navigate("/home");
  }

 

  return (
    <div>
       <Header/>
       
          { contact ? 
            (contact.map((value,index)=>{return( 
            <p key={index}>
            {value.name}
            {value.conatctNumber}
            <button type="button"  className="btn btn-danger" onClick={() => delId(value._id)} >Delete</button>
            </p> 
           
        
            )} ) )
           :
           "no data found"}
      
      <Footer/>
      </div>
  )
}

export default DeleteContact



