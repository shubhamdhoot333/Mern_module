export const Logininputfield = [ 
    { 
         id:"1",  
         fieldname:"Enter your name:",
         fieldvalue:"name",
         
    },
    {
        id:"2",
        fieldname:"Enter your Password:",
        fieldvalue:"password",
        
    }
    ]; 

 export  const  Registerinputfields = [ 
        { 
             id:"1",  
             fieldname:"Enter your name:",
             fieldvalue:"name",
             
        }, 
        { 
            id:"2",  
            fieldname:"Enter your Email:",
            fieldvalue:"email",
            
       },    
        {
            id:"3",
            fieldname:"Enter your Password:",
            fieldvalue:"password",
            
        }
        ];   
        
export const AddContactinputfield = [ 
            { 
                 id:"1",  
                 fieldname:"Enter contact name:",
                 fieldvalue:"name",
                 type:"text",
                 
            },
            {
                id:"2",
                fieldname:"Enter Contact number:",
                fieldvalue:"number",
                type:"number",
                 
                
            }
            ]; 
               
