import jwt from "jsonwebtoken";

export const Auth = (req, res, next) => {
  try {

    const token = req.cookies.jwtoken || req.headers.cookies || req.headers.jwtoken ;
    const verifyToken = jwt.verify(token, `MYNAMEISSHUBHAMDHOOTFROMJODHPUR`);
    if(verifyToken) next()
    else res.status(200).json({error: "unauthorised token"});
        
  } catch (error) {
         res.status(200).json({error: "Something wrong"});
    
  }
};
